var addToHomeScreen = document.querySelector('#add-home');

function addIconBanner() {
    if(deferredPrompt) {
        deferredPrompt.prompt();

        deferredPrompt.userChoice.then(function (choiceResult) {
            console.log(choiceResult.outcome);

            if(choiceResult.outcome === 'dismissed') {
                console.log('User batal menginstall');
            } else {
                console.log('User menginstall web ke Homescreen')
            }
        });

        deferredPrompt = null;
    }
}

addToHomeScreen.addEventListener('click', addIconBanner);